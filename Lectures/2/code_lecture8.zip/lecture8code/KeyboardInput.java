import java.io.*;

public class KeyboardInput
{
    public static char readChar()
    {
	// readChar() reads one character of keyboard input

	// charRead stores the character read from the keyboard
	int charRead = -1;  
	try {
	    // System.in.read reads a single character from the
	    // command line and returns it as an *integer*
	    charRead = System.in.read(); 
	}
	catch(IOException e) {
	    System.out.println(e.getMessage());
	    System.out.println("Exiting program...");
	    System.exit(0); 
	}

	// need to type cast the integer value obtained from 
	// System.in.read() back to a character before returning it
	return (char)charRead; 
    }

    public static String readLine() throws IOException
    {
	// readLine() reads one line of keyboard input (up to a return) 
	// from the command-line

	char nextChar;
	String lineRead="";
	boolean done = false;
	
	while (!done) {
	    nextChar = readChar();
	    // '\n' signals the end of the line, so we're done
	    if (nextChar == '\n') 
		done = true;
	    /* Some systems use two characters to signal the end of a 
	       line: '\r' followed by '\n'.  Ignore '\r' and wait for '/n' */
	    else if (nextChar == '\r'){
		// do nothing -- do not read this special character in
	    } 
	    else {
		/* append the new character read to the end of the 
		   string variable that stores the line we're reading */
		lineRead = lineRead + nextChar;
	    } 	    
	} 
	return lineRead;	
    }

    public static int readIntLine() throws IOException
    { 
	// read a line containing a string of digits and trim all whitespace
	// and control characters surrounding the digits
	boolean done = false;
	String inputString = null;
	int number = -1111;

	do {
	    System.out.print("Enter a number and then hit return: ");
	    try {
		inputString = readLine();
		// make sure we didn't get a line containing just whitespace
		inputString = inputString.trim();
		if (inputString.length() == 0)
		    // we only got whitespace; get input again
		    inputString = readLine();
		inputString = inputString.trim();
		number = Integer.parseInt(inputString);
		done = true;
	    } catch (NumberFormatException e) {
		System.out.println("Incorrect input. " +
				   "Please type in a string of digits.");
	    }
	} while (!done);
	return number;
    }

    public static void main(String[] args)
    {
	try{
	    String newStr = readLine();
	    System.out.println("You typed: " + newStr);
	}
	catch(IOException e){
	    System.out.println(e.getMessage());
	}
    }
}
