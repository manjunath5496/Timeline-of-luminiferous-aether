import java.io.*;

public class TestRotation{
    public static void main(String[] args)
    {
	/* Reads in a text file with encrypted contents that is passed as 
	   an argument to main from the command line, decrypts its
	   contents and writes the decypted text as output to a new
	   file called decryptedfile.txt */
	if (args.length == 1) {
	    System.out.println("Reading from file " + args[0]);
	    try {
		// create an input stream reader connection to the input file
		FileReader fr = new FileReader(args[0]);
		// create an output stream writer connection to the output file
		FileWriter fw = new FileWriter("decryptedfile.txt");
		// create a buffered reader for the input file
		BufferedReader in = new BufferedReader(fr);
		// create a buffered writer for the output file
		BufferedWriter out = new BufferedWriter(fw);
		int rotVal = 13;

		/* read a line of the input file using the buffered reader's
		   readLine() method.  readLine() returns null when it gets 
		   to the end of a file */
		String getLine = in.readLine();
		RotateText rotate = new RotateText();
		String rotatedText;
		while (getLine != null) {
		    // convert the string
		    rotatedText = rotate.rotateByNumber(getLine, rotVal);
		    // the buffered writer's write method writes out a line
		    // of text that is not followed by a new line
		    out.write(rotatedText, 0, rotatedText.length());
		    out.newLine(); // insert a newline character 
		    getLine = in.readLine();
		} 
		in.close();  // close the BufferedReader
		out.close(); // close the BufferedWriter
		System.out.println("Wrote decrypted text to file " +
				   "decryptedfile.txt");
	  } catch (FileNotFoundException e) {
	      System.err.println("File " + args[0] 
				 + " not found.");
	      return;
	  }
	  catch (IOException e1) {
	      System.err.println(e1.getMessage());
	      return;
	  }
	  catch (Exception e2) {
	      System.err.println(e2.getMessage());
	      return;
	  }
	}
    }
}
