import java.io.*;

public class TestRotation2{
    public static void main(String[] args)
    {
	/* Reads in a text file with encrypted contents that is passed as 
	   an argument to main from the command line, decrypts its
	   contents and writes the decypted text as output to a new
	   file called decryptedfile.txt */
	if (args.length == 1) {
	    System.out.println("Reading from file " + args[0]);
	    try {
		// create an input stream reader connection to the input file
		FileReader fr = new FileReader(args[0]);
		// create an output stream connection to the output file
		FileOutputStream fw = 
		    new FileOutputStream("decryptedfile.txt");
		// create a buffered reader for the input file
		BufferedReader in = new BufferedReader(fr);
		// create a print writer for the output file
		PrintWriter out = new PrintWriter(fw);
		int rotVal = 10;
		/* read a line of the input file using the buffered reader's
		   readLine() method.  readLine() returns null when it gets 
		   to the end of a file */
		String getLine = in.readLine();
		RotateText rotate = new RotateText();
		String rotatedText;
		while (getLine != null) {
		    // convert the string
		    rotatedText = rotate.rotateByNumber(getLine, rotVal);
                    // print a line containing the converted string to the output file
                    // using PrintWriter's println method
		    out.println(rotatedText);
		    getLine = in.readLine();
		} 
		in.close();  // close the BufferedReader
		out.close(); // close the PrintWriter
		System.out.println("Wrote decrypted text to file " +
				   "decryptedfile.txt");
	  } catch (FileNotFoundException e) {
	      System.err.println("File " + args[0] 
				 + " not found.");
	      return;
	  }
	  catch (IOException e1) {
	      System.err.println(e1.getMessage());
	      return;
	  }
	  catch (Exception e2) {
	      System.err.println(e2.getMessage());
	      return;
	  }
	}
    }
}
