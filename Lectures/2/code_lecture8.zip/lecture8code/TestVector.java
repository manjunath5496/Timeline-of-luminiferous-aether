import java.util.*;
import java.io.*;

public class TestVector 
{
    public static void main(String[] args)
    {
	/* create a new vector named userInput that has an 
	   initial capacity of 3 elements */

	Vector userInput = new Vector(3); 
	int num = 0;
	
	do {
	    // Accept integers typed in by the user until the user
	    // types in -99.  Store all the integers as Integer objects
	    // in the vector userInput
	    System.out.println("Enter a number and then hit return");
	    // get the number the user entered
	    try{
		num = Integer.parseInt(KeyboardInput.readLine());
		// create an Integer object for that number and store it
		userInput.addElement(new Integer(num));
	    }
	    catch(IOException e) {
		System.out.println(e.getMessage());
	    }
	    catch(NumberFormatException e1) {
		System.out.print("Number format exception: ");
		System.out.println(e1.getMessage());
	    }
	    catch(Exception e2) {
		System.out.print("General exception ");
		System.out.println(e2.getMessage());
	    }
	} while (num != -99);	
	
	System.out.println("Numbers entered were: ");
	Integer n;
	for (int i=0; i < userInput.size(); i++) {
	    n = (Integer)userInput.elementAt(i);
	    System.out.println(n.intValue());
	} 
    }
}
