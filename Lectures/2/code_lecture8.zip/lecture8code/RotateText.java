import java.io.*;

public class RotateText{

    public String rotateByNumber(String str, int num)
    {
	// rotates the characters in a string by num positions
	// this example uses arrays and the modulo operator
	// there are other ways to solve this that do not require
	// the use of arrays (saving storage space)
	char[] upperCaseChars = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I',
				 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
				 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
	char[] lowerCaseChars = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i',
				 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
				 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
	StringBuffer sb = new StringBuffer(str);
	int length = str.length();
	int numericValue = 0;
	int currPositionInArray = 0;
	int rotatedPositionInArray = 0;
	int i = 0;
        int upperCaseANumericValue = (int) 'A';
	int lowerCaseANumericValue = (int) 'a';
	boolean isUpperAlpha = false;
	boolean isLowerAlpha = false;
	char charAtIthPosition = ' ';

	for(i=0; i<length; i++) {
	    // get the ith character in the string
	    charAtIthPosition = str.charAt(i);
	    // find out whether it is upper or lower case
	    isUpperAlpha = ('A' <= charAtIthPosition) && 
		('Z' >= charAtIthPosition);
	    isLowerAlpha = ('a' <= charAtIthPosition) && 
		('z' >= charAtIthPosition);
	    numericValue = (int) charAtIthPosition;
	    
	    // rotate accordingly using arrays
	    if(isUpperAlpha) {
		currPositionInArray = numericValue - upperCaseANumericValue;
		rotatedPositionInArray = (currPositionInArray + num)%26;
		sb.setCharAt(i, upperCaseChars[rotatedPositionInArray]);
	    } 
	    else if(isLowerAlpha){
		currPositionInArray = numericValue - lowerCaseANumericValue;
		rotatedPositionInArray = (currPositionInArray + num)%26;
		sb.setCharAt(i, lowerCaseChars[rotatedPositionInArray]);
	    } 	    
	} 
	return(sb.toString());
    }
}


