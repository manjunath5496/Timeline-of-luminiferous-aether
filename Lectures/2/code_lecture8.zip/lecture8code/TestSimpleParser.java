import java.io.*;
import java.util.*;

public class TestSimpleParser{
    // reads a simple boolean expression typed in by the user
    // and outputs the value of that expression

    public static void main(String[] args)
    {
	int numOperands = 0;
	Vector expr = new Vector(3);
	boolean operand1;
	boolean operand2;
	String operator = null;
	String getLine = null;
	/* get input from user of the form
	   true and true 
	   true or false
	   not true, etc. */
	System.out.print("Type in a boolean expression:");
	try {
	    // get the user's input, but first clear any whitespace that 
	    // may have been introduced into the input stream
	    getLine = KeyboardInput.readLine();
	    getLine = getLine.trim();
	    if (getLine.length() == 0)
		// we only got a newline previously; get user's input again
		getLine = KeyboardInput.readLine();
	} catch (IOException ex) {
	    System.out.println(ex.getMessage());
	    System.out.println("Error, exiting...");
	    System.exit(0);
	}

	// break user input into tokens
	StringTokenizer st = new StringTokenizer(getLine, " \n\r\t");
	while (st.hasMoreTokens()) {
	    expr.addElement(st.nextToken());
	}
	
	if (expr.size() == 2)
	    {
		/* we may have a "not" expression: 
		   not true 
		   not false */
		try {
		    operator = (String) expr.elementAt(0);
		    String opnd = (String) expr.elementAt(1);
		    if (opnd.equals("true"))
			operand1 = true;
		    else if (opnd.equals("false"))
			operand1 = false;
		    else
			throw new Exception("Invalid expression!");
		    if (operator.equals("not"))
			{
			    System.out.println("The expression " + getLine +
					       " evaluates to " + !operand1);
			}
		    else
			throw new Exception("Invalid expression!");
		} catch (Exception e) {
		    System.out.println(e.getMessage());
		}
	    }
	else if (expr.size() == 3)
	    {
		/* we may have an "and" or "or" expression. e.g.,
		   true or false
		   true and false */
		try {
		    // get the first operand
		    String opnd = (String) expr.elementAt(0);
		    if (opnd.equals("true"))
			operand1 = true;
		    else if (opnd.equals("false"))
			operand1 = false;
		    else
			throw new Exception("Invalid expression: " + getLine 
					    + " !");

		    // get the second operand
		    opnd = (String) expr.elementAt(2);
		    if (opnd.equals("true"))
			operand2 = true;
		    else if (opnd.equals("false"))
			operand2 = false;
		    else
			throw new Exception("Invalid expression: " + getLine 
					    + " !");

		    // get the operator
		    operator = (String) expr.elementAt(1);
		    if (operator.equals("and")) {
			System.out.println("The expression " + getLine +
					   " evaluates to " + 
					   (operand1 && operand2));
		    }
		    else if (operator.equals("or")) {
			System.out.println("The expression " + getLine +
					   " evaluates to " + 
					   (operand1 || operand2));
			}
		    else
			throw new Exception("Invalid expression: " + getLine 
					    + " !");
		} catch (Exception e) {
		    System.out.println(e.getMessage());
		}
	    }
	else
	    System.out.println("Invalid expression: " + getLine 
			       + " !");	
    }
}
