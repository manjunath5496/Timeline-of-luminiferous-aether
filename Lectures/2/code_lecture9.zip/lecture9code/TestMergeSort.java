import java.util.*;

public class TestMergeSort
{
    // sort a Vector of integers using the selection sort method
    public static void main(String[] args)
    {
	Vector v = createVector();
	v = mergeSort(v);
	System.out.println("Sorted:");
	printIntVector(v);
    }

    public static Vector mergeSort(Vector v)
    {
	Vector firstHalf;
	Vector secondHalf;
	int size = v.size();
	int fSize = 0;

	if (size <= 1) {
	    return v;
	} 
	else {
	    fSize = size/2;

	    // split vector v into two vectors of roughly equal size
	    firstHalf = copyHalfVector(0, fSize-1, v);	    
	    secondHalf = copyHalfVector(fSize, size-1, v);
	    // merge sort each of the two half-vectors
	    firstHalf = mergeSort(firstHalf);
	    secondHalf = mergeSort(secondHalf);
	    // merge the two sorted half-vectors into a new sorted vector
	    v = merge(firstHalf, secondHalf);
	    return v;
	}	
    }

    public static Vector merge(Vector v1, Vector v2)
    {
	int i=0, j=0, k, el1, el2;
	int length = v1.size() + v2.size();
	boolean done = false;
	Vector newVec = new Vector(length);

	while (!done) {	
	    if (v1.size()==0) {
		k = 0;
		while(k < v2.size()) {
		    newVec.addElement(v2.elementAt(k));
		    k++;
		} 
		done = true;
	    } 
	    else if (v2.size()==0) {
		k = 0;
		while(k < v1.size()) {
		    newVec.addElement(v1.elementAt(k));
		    k++;
		} 
		done = true;
	    } 
	    else {
		el1 = ((Integer)(v1.elementAt(i))).intValue();
		el2 = ((Integer)(v2.elementAt(j))).intValue();
		if (el1 < el2) 
		    {
			// add first element of v1 to newVec
			newVec.addElement(v1.elementAt(i));
			// remove first element from v1
			v1.removeElementAt(i);
		    }
		else {	
		    // add first element of v2 to newVec    
		    newVec.addElement(v2.elementAt(j));
		    // remove first element from v2
		    v2.removeElementAt(j);
		}
	    }
	} 
	return newVec;
    }

    public static Vector copyHalfVector(int start, int end, Vector orig)
    {
	Vector temp = new Vector((end - start)+1);
	for (int i = start; i <= end; i++) {
	    temp.addElement(orig.elementAt(i));
	} 
	return (Vector)temp.clone();	
    }

    public static Vector createVector()
    {
	Vector vec = new Vector(14);
	for (int i = 0; i < 11; i++) {
	    vec.addElement(new Integer(100 - (i*10)));
	}
	System.out.println("Original: ");
	for (int j = 0;  j < vec.size(); j++) {
	    System.out.println("v(" + j + ") = " + vec.elementAt(j));
	}
	System.out.println();
	return (Vector)vec.clone();
    }
    
    public static void printIntVector(Vector v)
    {
	for (int j = 0;  j < v.size(); j++) {
	    System.out.println("v(" + j + ") = " 
			       + ((Integer)(v.elementAt(j))).intValue());
	}
	System.out.println();
    }

    
}
