public class TestSelectionSort
{
    // sort an array of integers using the selection sort method
    public static void main(String[] args)
    {
	int arr[] = {56, 1, 25, 9, 4, 1, 6, 5, 1, 13};
	selectionSort(arr, arr.length);
	for (int i=0; i < arr.length; i++)
	    System.out.print(arr[i] + " ");
	System.out.println();
    }

    public static void selectionSort(int A[], int numValidEntries)
    {
	int i, j, indexOfSmallest, temp;
	for (i=0; i < numValidEntries - 1; i++){
	    indexOfSmallest = i;
	    /* set indexOfSmallest to the index of the first occurrence
	       of the smallest element remaining in the unsorted part
	       of the array */
	    for (j = i+1; j < numValidEntries; j++) {
		if(A[j] < A[indexOfSmallest])
		    indexOfSmallest = j;			
	    }	 
	    /* at this point, indexOfSmallest is the index of the first 
	       smallest element in A[i]...A[numvalidEntries-1].  Now 
	       exchange A[indexOfSmallest] with A[i], where i is the 
	       first element in the unsorted part of the array */
	    temp = A[indexOfSmallest];
	    A[indexOfSmallest] = A[i];
	    A[i] = temp;
	}
    }
}
