public class TestBinarySearch
{
    // search a sorted array of integers using the binary search method
    public static void main(String[] args)
    {
	int arr[] = {-20, -3, 0, 4, 6, 23, 41, 48, 50, 62, 65, 88, 90, 93};
	
	int position = binarySearch(90, arr, 0, arr.length);
	if (position > -1)
	    System.out.println("The number 90 is at index " + position);
	else
	    System.out.println("Sorry, that number is not in the array");
    }

    public static int binarySearch(int target, int A[], int start, int end)
    {
	int result = -1;
	int midpoint;
	
	// use binary search to look for target in A[start]...A[end]
	// return the index of the target if foun or -1 if not found
	if (start > end)
	    // not found
	    result = -1;
	else {
	    midpoint = (start + end)/2;
	    if (target == A[midpoint])
		result = midpoint;
	    else if (target < A[midpoint])
		// search first half of array
		result = binarySearch(target, A, start, midpoint-1);
	    else // target > A[midpoint] -- search second half of array
		result = binarySearch(target, A, midpoint+1, end);
	}
	return result;
    }
}
